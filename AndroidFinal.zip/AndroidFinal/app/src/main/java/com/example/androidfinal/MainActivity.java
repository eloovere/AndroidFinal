package com.example.androidfinal;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.TimePicker;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    //variables
    private TimePicker t;
    private TextView txt;
    int hour, min;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //setting up button and timepicker
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t = (TimePicker)findViewById(R.id.alarmTimePicker);
        txt = (TextView)findViewById((R.id.alarmText));

        //displaying time alarm was set for
        t.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener(){
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                hour = hourOfDay;
                min= minute;
                txt.setText(txt.getText().toString()+"Alarm set for " + hour +":" + min +"\n");

            }
        });

    }

    public void setTimer(View view){
        //creating alarm and current date
        AlarmManager alarm = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        Date date = new Date();

        //creating calender one for current time and set time
        Calendar cal = Calendar.getInstance();
        Calendar calcurrent = Calendar.getInstance();
        cal.setTime(date);
        calcurrent.setTime(date);

        //getting/setting alarm for chosen time
        cal.set(Calendar.HOUR_OF_DAY,hour);
        cal.set(Calendar.MINUTE,min);
        cal.set(Calendar.SECOND,0);

        //ensuring it is later
        if(cal.before(calcurrent)){
            cal.add(Calendar.DATE,1);
        }

        //activating alarm
        Intent i = new Intent(MainActivity.this, broadcastRecieve.class);
        PendingIntent p = PendingIntent.getBroadcast(MainActivity.this,24444,i,0);
        alarm.set(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),p);

    }


}